package com.tns.Student_Service;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Student {

		
	@Id
	@Column(name="placementID")
	private long placementID;
		
	@Column(name="placementName")
		private String placementName;
		
		
		@Column(name="college")
		private String college;
		
		@Column(name="date")
		private LocalDate  date;
		
		@Column(name="qualification")
		private String qualification;
		
		@Column(name="year")
		private int year;
		
		
		public long getPlacementID() {
			return placementID;
		}

		public void setPlacementID(long placementID) {
			this.placementID = placementID;
		}

		public String getPlacementName() {
			return placementName;
		}

		public void setPlacementName(String placementName) {
			this.placementName = placementName;
		}

		public String getCollege() {
			return college;
		}

		public void setCollege(String college) {
			this.college = college;
		}

		public LocalDate getDate() {
			return date;
		}

		public void setDate(LocalDate date) {
			this.date = date;
		}

		public String getQualification() {
			return qualification;
		}

		public void setQualification(String qualification) {
			this.qualification = qualification;
		}

		public int getYear() {
			return year;
		}

		public void setYear(int year) {
			this.year = year;
		}

		public  Student() {
			super();
			// TODO Auto-generated constructor stub
		}

		public Student(long placementID, String placementName,String college, LocalDate date , String qualification,int year) {
			super();
			this.placementID = placementID;
			this.placementName = placementName;
			this.college = college;
			this.date= date;
			this.qualification =qualification;
			this.year=year;
		}

		@Override
		public String toString() {
			return "StudentEntity [placementID=" + placementID + ", placementName=" + placementName + ", college="
					+ college + ", date=" + date + ", qualification=" + qualification + ", year=" + year + "]";
		}

		
}		
		
		
		
