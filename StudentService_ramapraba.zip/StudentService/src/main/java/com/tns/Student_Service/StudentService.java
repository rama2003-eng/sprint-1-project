package com.tns.Student_Service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class StudentService {
	
		@Autowired
		private StudentRepository repo;
		
		public void save(Student employ)
		{
			repo.save(employ);
		}
		
		public List<Student> getAllStudent()
		{
			return repo.findAll();
		}
		
		public Student getStudentById(long id) 
		{
			return repo.findById(id).orElse(null);
		}
		
		public void deleteStudent(long id)
		{
			repo.deleteById(id);
		}

		public void updateStudent(long id , Student updatedStudent)
		{
			Student existingStudent = repo.findById(id).orElse(null);
			if (existingStudent != null)
			{
				existingStudent.setPlacementName(updatedStudent.getPlacementName());
				existingStudent.setCollege(updatedStudent.getCollege());
				existingStudent.setDate(updatedStudent.getDate());
				existingStudent.setQualification(updatedStudent.getQualification());
				existingStudent.setYear(updatedStudent.getYear());
				repo.save(existingStudent);
			}
		}
}


